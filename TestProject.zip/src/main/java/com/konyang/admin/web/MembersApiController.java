package com.konyang.admin.web;

import com.konyang.admin.service.MembersService;
import com.konyang.admin.web.dto.MembersSaveRequestDto;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
public class MembersApiController {

    private final MembersService membersService;

    @PostMapping("/api/v1/members")
    public Long save(@RequestBody MembersSaveRequestDto requestDto) {
        return membersService.save(requestDto);
    }
}

